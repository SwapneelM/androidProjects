package com.udacity.gradle;

public abstract class Echo {
    public static Object echo(Object input) {
        return input;
    }
}