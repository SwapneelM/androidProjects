package com.udacity.gradle;


public class JokeTeller {

    public static void main(String[] args){
        System.out.println("Java. Write once, debug everywere.");
    }
}
