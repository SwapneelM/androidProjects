package com.udacity.gradle.jokesource;

public class JokeSource {

    public String getJoke(){
        return "This is a joke from a Java Library";
    }
}
