package com.udacity.example.jokes;

import java.lang.String;

public class JokeSmith{
    public String tellAHandCraftedJoke(){
        return "A hand-crafted joke";
    }
}

